/*

// Template for iRulesLX RPC.
// Note: This example works in concert with the template provided in the default ilx TCL iRule
// that is created when a new workspace is created.

// Import the f5-nodejs module.
var f5 = require('f5-nodejs');

// Create a new rpc server for listening to TCL iRule calls.
var ilx = new f5.ILXServer();

// Create and register a remote function to be triggered by a TCL
// iRule ILX::call or ILX::notify.
//
// To use, uncomment the block below, replace <REMOTE_FUNC_NAME>, and make sure
// whatever it is replaced with appears in the corresponding iRule
// ILX::call or ILX::notify calls.
//

// ilx.addMethod('<REMOTE_FUNC_NAME>', function(req, res) {
//   // Function parameters can be found in req.params().
//   console.log('params: ' + req.params());
//   // Whatever is placed in res.reply() will be the return value from ILX::call.
//   res.reply('<RESPONSE>');
// });

// You can also return an array, which will be presented in the TCL iRule as a list.
// Use the 'lindex' TCL command to access individual items within the list.
// ilx.addMethod('<REMOTE_FUNC_NAME>', function(req, res) {
//   // Function parameters can be found in req.params().
//   console.log('params: ' + req.params());
//   // An array placed in res.reply() will be the list returned by ILX::call.
//   res.reply(['<ITEM1>', '<ITEM2>']);
// });

// Start listening for ILX::call and ILX::notify events.
ilx.listen();

*/

/*

// Template for iRulesLX Streaming. This example forwards to the server what is received from the
// client, and forwards to the client what is received from the server.

// Import the f5-nodejs module.
var f5 = require('f5-nodejs');
var plugin = new f5.ILXPlugin();

// Register a callback for new connections received by a Virtual Server.
plugin.on("connect", function(flow) {

	// Register a callback to read payload data from the client and forward to the server.
    flow.client.on("readable", function() {
        while (true) {
            var buffer = flow.client.read();
            if (buffer !== null) {
                flow.server.write(buffer);
            }
            else {
                break;
            }
        }
    });

     // Create and register a callback to read payload data from the server and forward to
     // the client.
    flow.server.on("readable", function() {
        while (true) {
            var buffer = flow.server.read();
            if (buffer !== null) {
                flow.client.write(buffer);
            }
            else {
                break;
            }
        }
    });

	// Register callbacks for error events. Errors events must be caught.
    flow.client.on("error", function(errorText) {
        console.log("client error event: " + errorText);
    });
    flow.server.on("error", function(errorText) {
        console.log("server error event: " + errorText);
    });
    flow.on("error", function(errorText) {
        console.log("flow error event: " + errorText);
    });
});

// Start listening for new flows.
var options = new f5.ILXPluginOptions(); // options are optional
plugin.start(options);

*/

/*

// Template for iRulesLX Streaming with an HTTP profile on the Virtual Server.

var f5 = require('f5-nodejs');
var plugin = new f5.ILXPlugin();

// Register a callback for new connections received by a Virtual Server.
plugin.on("connect", function(flow) {

    // Received HTTP request headers from client
    flow.client.on("requestStart", function(request) {
        console.log("HTTP request: " + JSON.stringify(request.params));
    });

    // Read the body of the HTTP request and forward to server
    flow.client.on("readable", function() {
        while (true) {
            var buffer = flow.client.read();
            if (buffer !== null) {
                flow.server.write(buffer);
            }
            else {
                break;
            }
        }
    });

    // Entire HTTP request has been received, headers and body
    flow.client.on("requestComplete", function(request) {
        request.complete();
    });

    // Received HTTP response headers from server
    flow.server.on("responseStart", function(response) {
        console.log("HTTP response: " + JSON.stringify(response.params));
    });

    // Read the body of the HTTP response and forward to client
    flow.server.on("readable", function() {
        while (true) {
            var buffer = flow.server.read();
            if (buffer !== null) {
                flow.client.write(buffer);
            }
            else {
                break;
            }
        }
    });

    // Entire HTTP response has been received, headers and body
    flow.server.on("responseComplete", function(response) {
        response.complete();
    });

	// Register callbacks for error events. Errors events must be caught.
    flow.client.on("error", function(errorText) {
        console.log("client error event: " + errorText);
    });
    flow.server.on("error", function(errorText) {
        console.log("server error event: " + errorText);
    });
    flow.on("error", function(errorText) {
        console.log("flow error event: " + errorText);
    });
});


// Start listening for new flows.
plugin.start(options);

*/

